import cv2
import time
import os
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class CameraRecorder:
    def __init__(self, rtsp_url=None):
        self.rtsp_url = rtsp_url if rtsp_url else "rtsp://admin: 123456@192.168.0.105"  # 默认RTSP地址
        self.cap = None  # 摄像头捕获对象
        self.out = None  # 视频写入对象
        self.recording = False  # 录制状态标志
        self.fps = 25  # 默认帧率
        self.width = 0  # 视频宽度
        self.height = 0  # 视频高度
        self.output_file = ""  # 输出文件路径

    def open_camera(self):
        """开启摄像头或RTSP流"""
        if self.cap is not None and self.cap.isOpened():
            logger.info("摄像头已处于开启状态")
            return True

        os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = "rtsp_transport;tcp|timeout;60000000"
        self.cap = cv2.VideoCapture(self.rtsp_url)

        if not self.cap.isOpened():
            logger.error("无法打开摄像头或RTSP流")
            self.cap = None
            return False

        # 获取视频参数
        self.fps = self.cap.get(cv2.CAP_PROP_FPS) or 25
        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        logger.info(f"摄像头开启成功，分辨率: {self.width}x{self.height}，帧率: {self.fps}")
        return True

    def start_recording(self):
        """开始录制视频"""
        if self.recording:
            logger.info("已处于录制状态")
            return True

        if not self.cap or not self.cap.isOpened():
            logger.error("请先开启摄像头")
            return False

        # 生成唯一的输出文件名
        self.output_file = f"output_{int(time.time())}.mp4"
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        self.out = cv2.VideoWriter(self.output_file, fourcc, self.fps, (self.width, self.height))

        if not self.out.isOpened():
            logger.error("无法初始化视频写入器")
            self.out = None
            return False

        self.recording = True
        logger.info(f"开始录制，视频将保存为: {self.output_file}")
        return True

    def stop_recording(self):
        """停止录制视频"""
        if not self.recording:
            logger.info("未处于录制状态")
            return True

        if self.out and self.out.isOpened():
            self.out.release()
            self.out = None

        self.recording = False
        logger.info(f"停止录制，视频已保存到: {os.path.abspath(self.output_file)}")
        return True

    def close_camera(self):
        """关闭摄像头"""
        # 如果正在录制，先停止录制
        if self.recording:
            self.stop_recording()

        if self.cap and self.cap.isOpened():
            self.cap.release()
            self.cap = None
            cv2.destroyAllWindows()
            logger.info("摄像头已关闭")
            return True

        logger.info("摄像头已处于关闭状态")
        return True

    def run_camera_viewer(self):
        """运行摄像头预览窗口"""
        if not self.cap or not self.cap.isOpened():
            logger.error("请先开启摄像头")
            return

        logger.info("开启摄像头预览，按 'q' 退出，按 's' 开始/停止录制")

        try:
            while True:
                ret, frame = self.cap.read()
                if not ret:
                    logger.error("无法读取视频帧")
                    break

                # 显示录制状态
                status_text = "录制中" if self.recording else "未录制"
                cv2.putText(frame, status_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1,
                            (0, 255, 0) if self.recording else (0, 0, 255), 2)
                cv2.imshow('摄像头预览', frame)

                # 处理按键
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    logger.info("用户退出预览")
                    break
                elif key == ord('s'):
                    if self.recording:
                        self.stop_recording()
                    else:
                        self.start_recording()

        except KeyboardInterrupt:
            logger.info("用户中断预览")
        finally:
            # 确保资源释放
            self.close_camera()


if __name__ == "__main__":
    # 创建摄像头录制器实例
    recorder = CameraRecorder()

    # 开启摄像头
    recorder.open_camera()

    # 运行摄像头预览
    recorder.run_camera_viewer()