from socket import socket,AF_INET ,SOCK_STREAM

# AF_INET:用于Internet之间的进程通讯
# SOCK_STREAM:表示用于TCP协议编程

#创建套接字
server_socket = socket(AF_INET,SOCK_STREAM)

ip='' #任意自己的ip
port=8082

#绑定bind
server_socket.bind((ip,port))

#监听套接字listen
server_socket.listen(5)
print('Waiting for a connection...')

#等待连接
user_socket,user_addr = server_socket.accept() #阻塞
print('用户:'+str(user_addr[0])+'连接成功')

data = ''
while data != 'byebye':
    data = user_socket.recv(1024).decode('gbk')
    print(data,type(data))
    user_socket.send(data.encode('gbk'))

#关闭socket
server_socket.close()

