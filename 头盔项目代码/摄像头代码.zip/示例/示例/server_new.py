from socket import socket,AF_INET ,SOCK_STREAM
import os
import dashscope

# AF_INET:用于Internet之间的进程通讯
# SOCK_STREAM:表示用于TCP协议编程

messages = [
    {'role': 'system', 'content': 'You are a helpful assistant.'},
    {'role': 'user', 'content': '介绍一下stm32？'}
    ]

#创建套接字
server_socket = socket(AF_INET,SOCK_STREAM)

ip=''
port=8080
#绑定bind
server_socket.bind((ip,port))

#监听套接字listen
server_socket.listen(5)
print('Waiting for a connection...')

#等待连接
user_socket,user_addr = server_socket.accept() #阻塞
print('用户:'+str(user_addr[0])+'连接成功')

data = ''
while data != 'byebye':
    data = user_socket.recv(1024).decode('gbk')
    print(data,type(data))
    if data[0:2] == "aa":
        print('here')
        #把esp32中的数据放进去
        messages[1]["content"] = data
        response = dashscope.Generation.call(
            # 若没有配置环境变量，请用百炼API Key将下行替换为：api_key="sk-xxx",
            api_key="sk-262e3bcd3f9a4df0b6b5a58e3c28df20",
            model="qwen-max",  # 模型列表：https://help.aliyun.com/zh/model-studio/getting-started/models
            messages=messages,
            result_format='message'
        )
        print(response["output"]["choices"][0]["message"]["content"])
        user_socket.send(response["output"]["choices"][0]["message"]["content"].encode('gbk'))
    #user_socket.send(data.encode('gbk'))

#关闭socket
server_socket.close()

