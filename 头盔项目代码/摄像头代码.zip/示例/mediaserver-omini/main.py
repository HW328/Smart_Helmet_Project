from dotenv import load_dotenv
load_dotenv()
import os
import asyncio
import paho.mqtt.client as mqtt
from utils import get_latest_file_from_latest_folder
from http_requests import upload_video_and_text, camera_register, stop_recording, start_recording, omini_video_parser


on_capture = None


async def detect_once(client):
    await start_recording()
    await asyncio.sleep(10)
    await stop_recording()
    await asyncio.sleep(1)
    file_path = get_latest_file_from_latest_folder(os.getenv("SAVE_BASE_PATH"))
    results = await asyncio.to_thread(omini_video_parser, file_path)
    client.publish("mine/llm_results", payload=results)
    await upload_video_and_text(file_path, results)


def on_message(client, userdata, msg):
    global on_capture
    if str(msg.topic) == os.getenv("MQTT_TOPIC"):
        on_capture = True


def setup_mqtt():
    client = mqtt.Client()
    client.on_message = on_message
    client.connect(os.getenv("MQTT_BROKER"), int(os.getenv("MQTT_PORT")), keepalive=60)
    client.subscribe(os.getenv("MQTT_TOPIC"))
    client.loop_start()
    return client

# 主 async 函数
async def main():
    global on_capture
    await camera_register()
    client = setup_mqtt()

    while True:
        if on_capture:
            await detect_once(client)
            on_capture = False


asyncio.run(main())