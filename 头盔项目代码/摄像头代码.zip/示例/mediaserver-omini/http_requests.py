import asyncio
import aiohttp
import os
from pathlib import Path
from openai import OpenAI
from utils import encode_video


BASE_URL = os.getenv('MEDIA_SERVER_URL')
SECRET_KEY = os.getenv('MEDIA_SERVER_SECRET')


async def camera_register(vhost="__defaultVhost__", app="sandtable", stream="0", url=os.getenv("RTSP_URL")):
    params = {
        "vhost": vhost,
        "app": app,
        "stream": stream,
        "url": url,
        "secret": SECRET_KEY
    }
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{BASE_URL}/index/api/addStreamProxy", params=params) as resp:
            result = await resp.json()
            print("camera_register:", result)
            return result


async def start_recording(type_="1", vhost="__defaultVhost__", app="sandtable", stream="0",
                         customized_path="00001"):
    params = {
        "type": type_,
        "vhost": vhost,
        "app": app,
        "stream": stream,
        "secret": SECRET_KEY,
        "customized_path": customized_path
    }
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{BASE_URL}/index/api/startRecord", params=params) as resp:
            result = await resp.json()
            print("start_recording:", result)
            return result


async def stop_recording(type_="1", vhost="__defaultVhost__", app="sandtable", stream="0"):
    params = {
        "type": type_,
        "vhost": vhost,
        "app": app,
        "stream": stream,
        "secret": SECRET_KEY
    }
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{BASE_URL}/index/api/stopRecord", params=params) as resp:
            result = await resp.json()
            print("stop_recording:", result)
            return result



def omini_video_parser(video_path):
    client = OpenAI(
        # 若没有配置环境变量，请用阿里云百炼API Key将下行替换为：api_key="sk-xxx",
        api_key=os.getenv("DASHSCOPE_API_KEY"),
        base_url=os.getenv("DASHSCOPE_API_URL")
    )

    base64_video = encode_video(video_path)

    completion = client.chat.completions.create(
        model="qwen3.5-omni-plus",
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "video_url",
                        "video_url": {"url": f"data:;base64,{base64_video}"
                        },
                    },
                    {"type": "text", "text": "视频的内容是什么?"},
                ],
            },
        ],
        modalities=["text"],
        # stream 必须设置为 True，否则会报错
        stream=True,
        stream_options={"include_usage": True},
    )
    results = ""
    for chunk in completion:
        if chunk.choices:
            print(chunk.choices[0].delta.content)
            results += chunk.choices[0].delta.content
        else:
            print(chunk.usage)
    return results


async def upload_video_and_text(video_path: str, text: str):
    url = os.getenv("DB_SERVER_URL")

    # 检查视频文件是否存在
    if not Path(video_path).is_file():
        raise FileNotFoundError(f"视频文件不存在: {video_path}")

    # aiohttp 提交 multipart/form-data
    async with aiohttp.ClientSession() as session:
        with open(video_path, 'rb') as video_file:
            form_data = aiohttp.FormData()
            form_data.add_field("video", video_file, filename=Path(video_path).name, content_type='video/mp4')
            form_data.add_field("text", text)

            async with session.post(url, data=form_data) as resp:
                response_text = await resp.text()
                print(f"Status: {resp.status}")
                print(f"Response: {response_text}")
                return resp.status, response_text

async def main():
    # results = await asyncio.to_thread(omini_video_parser, r"E:\mediaserver\ZLMediaKit20240419\ZLMediaKit20240419\Release\00001\record\sandtable\0\2025-08-06\11-33-35-0.mp4")
    # print(results)
    # await camera_register()
    # await start_recording()
    # await asyncio.sleep(12)
    await stop_recording()

if __name__ == '__main__':
    from dotenv import load_dotenv
    load_dotenv()
    asyncio.run(main())



