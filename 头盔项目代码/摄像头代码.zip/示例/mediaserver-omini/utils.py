import os
from pathlib import Path
import base64


def encode_video(video_path):
    with open(video_path, "rb") as video_file:
        return base64.b64encode(video_file.read()).decode("utf-8")


def get_latest_file_from_latest_folder(parent_dir):
    # 获取所有子文件夹（只包含目录）
    subdirs = [d for d in Path(parent_dir).iterdir() if d.is_dir()]

    if not subdirs:
        raise Exception("没有找到任何子文件夹")

    # 根据文件夹名称（日期）排序，假设命名格式为 YYYY-MM-DD
    latest_folder = sorted(subdirs, key=lambda x: x.name)[-1]

    # 获取该文件夹下的所有文件（只包括文件）
    files = [f for f in latest_folder.iterdir() if f.is_file()]

    if not files:
        raise Exception(f"子文件夹 {latest_folder} 中没有文件")

    # 根据修改时间排序
    latest_file = max(files, key=lambda x: x.stat().st_mtime)

    return str(latest_file)


if __name__ == "__main__":

    parent_directory = r"E:/mediaserver/ZLMediaKit20240419/ZLMediaKit20240419/Release/00001/record/sandtable/0" # 替换为你的实际路径
    latest_file_path = get_latest_file_from_latest_folder(parent_directory)
    print("最新文件路径:", latest_file_path)
