import asyncio
import websockets
import json

async def websocket_client():
    uri = "ws://localhost:8765"
    
    try:
        async with websockets.connect(uri) as websocket:
            print("✅ 成功连接到WebSocket服务器")
            print("等待接收数据...\n")
            
            count = 0
            while True:
                try:
                    message = await websocket.recv()
                    count += 1
                    
                    data = json.loads(message)
                    
                    print(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                    print(f"📊 第 {count} 次收到数据")
                    print(f"⏰ 时间: {data.get('timestamp', 'N/A')}")
                    print(f"🌡️ 温度: {data.get('temperature', 'N/A')} °C")
                    print(f"💧 湿度: {data.get('humidity', 'N/A')} %")
                    print(f"⛽ 甲烷: {data.get('methane', 'N/A')} ppm")
                    print(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")
                    
                except websockets.exceptions.ConnectionClosed:
                    print("\n❌ 连接已断开")
                    break
                except Exception as e:
                    print(f"❌ 处理数据出错: {e}")
                    
    except ConnectionRefusedError:
        print("❌ 无法连接到WebSocket服务器")
        print("请确保已先运行 sensor_server.py 或 test_server.py")
    except Exception as e:
        print(f"❌ 连接出错: {e}")

if __name__ == "__main__":
    print("WebSocket测试客户端启动中...")
    print("服务器地址: ws://localhost:8765\n")
    
    try:
        asyncio.run(websocket_client())
    except KeyboardInterrupt:
        print("\n测试客户端已停止")
