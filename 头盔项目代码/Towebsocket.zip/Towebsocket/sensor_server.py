import serial
import asyncio
import websockets
import json
from datetime import datetime
import argparse

class SensorWebSocketServer:
    def __init__(self, serial_port, baud_rate=9600, websocket_port=8765):
        self.serial_port = serial_port
        self.baud_rate = baud_rate
        self.websocket_port = websocket_port
        self.connected_clients = set()
        self.serial_conn = None
        self.buffer = ""

    async def connect_serial(self):
        try:
            self.serial_conn = serial.Serial(
                port=self.serial_port,
                baudrate=self.baud_rate,
                timeout=1
            )
            print(f"串口连接成功: {self.serial_port} @ {self.baud_rate}")
        except Exception as e:
            print(f"串口连接失败: {e}")
            raise

    async def register_client(self, websocket):
        self.connected_clients.add(websocket)
        print(f"新客户端连接，当前连接数: {len(self.connected_clients)}")

    async def unregister_client(self, websocket):
        if websocket in self.connected_clients:
            self.connected_clients.remove(websocket)
        print(f"客户端断开，当前连接数: {len(self.connected_clients)}")

    async def broadcast(self, message):
        if self.connected_clients:
            disconnected_clients = set()
            for client in self.connected_clients:
                try:
                    await client.send(message)
                except Exception as e:
                    print(f"发送消息失败: {e}")
                    disconnected_clients.add(client)
            for client in disconnected_clients:
                await self.unregister_client(client)

    async def read_serial_data(self):
        while True:
            try:
                if self.serial_conn and self.serial_conn.in_waiting > 0:
                    chunk = self.serial_conn.read(self.serial_conn.in_waiting).decode('utf-8', errors='ignore')
                    self.buffer += chunk
                    
                    while '\n' in self.buffer or '\r' in self.buffer:
                        lines = self.buffer.splitlines()
                        if lines:
                            line = lines.pop(0).strip()
                            self.buffer = '\n'.join(lines)
                            
                            if line and self.is_complete_data(line):
                                print(f"接收到串口数据: {line}")
                                sensor_data = self.parse_sensor_data(line)
                                if sensor_data:
                                    await self.broadcast(json.dumps(sensor_data))
            except Exception as e:
                print(f"读取串口数据出错: {e}")
                await asyncio.sleep(1)
            await asyncio.sleep(0.01)
    
    def is_complete_data(self, data_str):
        has_t = "T:" in data_str
        has_h = "H:" in data_str
        has_ch4 = "CH4:" in data_str
        return has_t and has_h and has_ch4

    def parse_sensor_data(self, data_str):
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            data = {
                "timestamp": timestamp,
                "temperature": 0.0,
                "humidity": 0.0,
                "methane": 0.0
            }
            
            if "T:" in data_str or "temperature" in data_str.lower():
                temp_val = self.extract_value(data_str, ["T:", "温度:", "temperature:"])
                if temp_val is not None:
                    data["temperature"] = temp_val
            
            if "H:" in data_str or "humidity" in data_str.lower():
                hum_val = self.extract_value(data_str, ["H:", "湿度:", "humidity:"])
                if hum_val is not None:
                    data["humidity"] = hum_val
            
            if "CH4:" in data_str or "methane" in data_str.lower():
                methane_val = self.extract_value(data_str, ["CH4:", "甲烷:", "methane:"])
                if methane_val is not None:
                    data["methane"] = methane_val
            
            if data_str.startswith("DATA:"):
                parts = data_str.split(",")
                for part in parts:
                    if "CH4:" in part:
                        ch4_part = part.split("CH4:")[-1]
                        try:
                            data["methane"] = float(ch4_part)
                        except:
                            pass
            
            try:
                json_data = json.loads(data_str)
                data.update(json_data)
            except:
                pass
            
            return data
        except Exception as e:
            print(f"解析传感器数据失败: {e}")
            return None

    def extract_value(self, data_str, keywords):
        for keyword in keywords:
            if keyword in data_str:
                start_idx = data_str.index(keyword) + len(keyword)
                end_idx = start_idx
                while end_idx < len(data_str) and (data_str[end_idx].isdigit() or data_str[end_idx] == '.'):
                    end_idx += 1
                try:
                    return float(data_str[start_idx:end_idx])
                except:
                    pass
        return None

    async def websocket_handler(self, websocket, path=None):
        await self.register_client(websocket)
        try:
            async for message in websocket:
                print(f"收到客户端消息: {message}")
        except Exception as e:
            print(f"WebSocket连接异常: {e}")

        finally:
            await self.unregister_client(websocket)

    async def run(self):
        await self.connect_serial()
        asyncio.create_task(self.read_serial_data())
        
        print(f"WebSocket服务器启动，端口: {self.websocket_port}")
        async with websockets.serve(self.websocket_handler, "0.0.0.0", self.websocket_port):
            await asyncio.Future()

def main():
    parser = argparse.ArgumentParser(description='传感器数据WebSocket服务器')
    parser.add_argument('--port', '-p', type=str, default='COM3', help='串口号 (Windows: COM3, Linux: /dev/ttyUSB0)')
    parser.add_argument('--baud', '-b', type=int, default=9600, help='波特率')
    parser.add_argument('--wsport', '-w', type=int, default=8765, help='WebSocket端口')
    
    args = parser.parse_args()
    
    server = SensorWebSocketServer(
        serial_port=args.port,
        baud_rate=args.baud,
        websocket_port=args.wsport
    )
    
    try:
        asyncio.run(server.run())
    except KeyboardInterrupt:
        print("\n服务器停止")
    except Exception as e:
        print(f"服务器运行异常: {e}")

if __name__ == "__main__":
    main()
