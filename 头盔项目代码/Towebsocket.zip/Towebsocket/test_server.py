import asyncio
import json
import random
from datetime import datetime
import websockets

class TestSensorWebSocketServer:
    def __init__(self, websocket_port=8765):
        self.websocket_port = websocket_port
        self.connected_clients = set()

    # 修复：添加 path 参数
    async def websocket_handler(self, websocket, path=None):
        self.connected_clients.add(websocket)
        print(f"客户端已连接，当前连接数: {len(self.connected_clients)}")
        try:
            await websocket.wait_closed()
        finally:
            self.connected_clients.remove(websocket)
            print(f"客户端已断开，当前连接数: {len(self.connected_clients)}")

    async def broadcast(self, message):
        if self.connected_clients:
            await asyncio.gather(
                *[client.send(message) for client in self.connected_clients]
            )

    async def generate_simulated_data(self):
        while True:
            data = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "temperature": round(random.uniform(20, 35), 2),
                "humidity": round(random.uniform(30, 90), 2),
                "methane": round(random.uniform(10, 400), 2)
            }
            print(f"生成模拟数据: {json.dumps(data)}")
            await self.broadcast(json.dumps(data))
            await asyncio.sleep(2)

    async def run(self):
        async with websockets.serve(self.websocket_handler, "0.0.0.0", self.websocket_port):
            print(f"测试WebSocket服务器启动，端口: {self.websocket_port}")
            await self.generate_simulated_data()

if __name__ == "__main__":
    server = TestSensorWebSocketServer()
    asyncio.run(server.run())
