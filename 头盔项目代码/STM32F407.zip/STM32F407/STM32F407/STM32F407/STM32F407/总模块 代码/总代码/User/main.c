#include "stm32f4xx.h" 
#include "System.h"
#include "Delay.h"
#include "MQ4.h"
#include "OLED.h"
#include "FMQ.h"
#include "VIBRATE.h"
#include "uart.h"
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdarg.h>
#include "uartbletooth.h"
#include "uart4.h"

#define SUCCESS 1
#define ERROR   0

char receivedChar;
int Vibrate_Level;
int Vibrate_Leve2;

int main(void)
{
    char display_buffer[32];
    char uart4_buffer[64];
    float ppm_value;
	  uint8_t usart3ReceivedData = 0;  
    uint8_t usart3ReceiveFlag = 0;   
	  const char *warning_msg = "1\r\n";
	 
    Delay_us(100);
    SystemInit();
    
    MQ4_Init();           
    MQ4_Calibrate();    
    OLED_Init();        
    OLED_Clear();       
    mfq_Init();
	  VIBRATE_Init();     
    USART2_Init();
	  USART3_Init();
    USART4_Init();
    OLED_ShowString(0, 0, "MQ4 Gas Sensor", OLED_8X16);
    OLED_Update();
	  
    while(1)
    {
        ////MQ4 读取
        ppm_value = MQ4_GetPPM();  
        
        // OLED 显示
        OLED_ClearArea(0, 2, 128, 64); 
        sprintf(display_buffer, "CH4: %.2f PPM", ppm_value);
        OLED_ShowString(0, 2, display_buffer, OLED_8X16);
			  OLED_Update();
        
        // 串口4发送甲烷数据
			sprintf(uart4_buffer, "T:27.0 H:56.2 CH4:%.0f\r\n", ppm_value);
        USART4_SendString(uart4_buffer);
        
        // 报警判断
			  if(ppm_value>10000)
			  {
		 	    USART2_SendString(warning_msg);
		      USART3_SendChar('1');
			  }
		
        Delay_ms(500);
        
			  // 振动传感器检测
			  Vibrate_Level=VIBRATE_Get();
		 	  Vibrate_Leve2=VIBRATE_Get1();
			  if(Vibrate_Leve2==1&&Vibrate_Level==1)
			  {
		 	
				  fmq_on();				
			  }
			  else
			  {
				  fmq_off();
				
			  }
        
//	     USART3_CheckReceive();
//    if (usart3ReceiveFlag) {
//        if (usart3ReceivedData == '3') {
//            USART2_SendChar('2');  
//					
//           }
//        usart3ReceiveFlag = 0;  
//        }
    
      }
}

