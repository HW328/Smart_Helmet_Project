#include "stm32f4xx.h"                 
#include "VIBRATE.h"


void VIBRATE_Init(void)
{	
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

	GPIO_InitStructure.GPIO_Pin = VIBRATE_PIN|GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
}

uint8_t VIBRATE_Get(void)
{
		return GPIO_ReadInputDataBit(VIBRATE_PORT, VIBRATE_PIN);
 
}
uint8_t VIBRATE_Get1(void)
{
	return GPIO_ReadInputDataBit(GPIOA ,GPIO_Pin_8);
}
