#ifndef __USART4_H
#define __USART4_H
#include "stm32f4xx.h"

#define USART4_BAUDRATE 9600  

void USART4_Init(void);
void USART4_SendChar(uint8_t ch);
uint8_t USART4_ReceiveChar(void);
void USART4_SendString(const char* str);

#endif
