#include "MQ4.h"
#include "math.h"
#include "Delay.h"
#include "stm32f4xx_adc.h"
#include "stm32f4xx_gpio.h"
static float R0 = 10.0f;  


void MQ4_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct;
    ADC_InitTypeDef ADC_InitStruct;
    ADC_CommonInitTypeDef ADC_CommonInitStruct;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AN;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;  
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    ADC_CommonInitStruct.ADC_Prescaler = ADC_Prescaler_Div4;  
    ADC_CommonInitStruct.ADC_Mode = ADC_Mode_Independent;
    ADC_CommonInitStruct.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
    ADC_CommonInitStruct.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
    ADC_CommonInit(&ADC_CommonInitStruct);

    ADC_InitStruct.ADC_Resolution = ADC_Resolution_12b;
    ADC_InitStruct.ADC_ScanConvMode = DISABLE;
    ADC_InitStruct.ADC_ContinuousConvMode = DISABLE;
    ADC_InitStruct.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
    ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStruct.ADC_NbrOfConversion = 1;
    ADC_Init(ADC1, &ADC_InitStruct);

    ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 1, ADC_SampleTime_480Cycles);
    
    ADC_Cmd(ADC1, ENABLE);
}


uint16_t MQ4_ReadADC(void) {
    ADC_SoftwareStartConv(MQ4_ADC);
    while(!ADC_GetFlagStatus(MQ4_ADC, ADC_FLAG_EOC));
    return ADC_GetConversionValue(MQ4_ADC);
}

void MQ4_Calibrate(void) {
    uint16_t adc_val = MQ4_ReadADC();
    float Vrl = VREF * adc_val / 4095.0f;
    float RS = (VREF - Vrl) / Vrl * RL;
    R0 = RS / powf(CAL_PPM / 98.322f, 1 / -1.458f);  
}


float MQ4_GetPPM(void) {
    uint16_t adc_val = MQ4_ReadADC();
    float Vrl = VREF * adc_val / 4095.0f;
    float RS = (VREF - Vrl) / Vrl * RL;
    return 98.322f * powf(RS/R0, -1.458f); 
}


