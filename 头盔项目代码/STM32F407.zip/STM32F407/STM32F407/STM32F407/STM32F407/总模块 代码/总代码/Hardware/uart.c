#include "uart.h"
#include <string.h>

void USART2_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    USART_InitTypeDef USART_InitStruct = {0};

    
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);  

    
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);  
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2);  

    
    USART_InitStruct.USART_BaudRate = USART2_BAUDRATE;
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;
    USART_InitStruct.USART_StopBits = USART_StopBits_1;
    USART_InitStruct.USART_Parity = USART_Parity_No;
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStruct.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART2, &USART_InitStruct);

    
    USART_Cmd(USART2, ENABLE);
}

void USART2_SendChar(uint8_t ch) {
    while(!(USART2->SR & USART_SR_TXE));  
    USART2->DR = (ch & 0xFF);
}

uint8_t USART2_ReceiveChar(void) {
    while(!(USART2->SR & USART_SR_RXNE));  
    return (uint8_t)(USART2->DR & 0xFF);
}

void USART2_SendString(const char *str) {
    while(*str) {
        while(!(USART2->SR & USART_SR_TXE));  
        USART2->DR = (*str++ & 0xFF);         
    }
    while(!(USART2->SR & USART_SR_TC));       
}
