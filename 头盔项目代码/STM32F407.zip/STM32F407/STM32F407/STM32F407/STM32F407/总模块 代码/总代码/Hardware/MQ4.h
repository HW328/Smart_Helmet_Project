
#ifndef __MQ4_H
#define __MQ4_H

#include "stm32f4xx.h"


#define MQ4_ADC               ADC1
#define MQ4_ADC_CHANNEL       ADC_Channel_1  
#define MQ4_ADC_CLK           RCC_APB2Periph_ADC1
#define MQ4_GPIO_PORT         GPIOA
#define MQ4_GPIO_PIN          GPIO_Pin_1
#define MQ4_GPIO_CLK          RCC_AHB1Periph_GPIOA
#define MQ4_SAMPLE_TIME       ADC_SampleTime_480Cycles  

#define CAL_PPM     10         
#define RL          10         
#define VREF        3.3f        


void MQ4_Init(void);
float MQ4_GetPPM(void);
void MQ4_Calibrate(void);
uint16_t MQ4_ReadADC(void);

#endif

