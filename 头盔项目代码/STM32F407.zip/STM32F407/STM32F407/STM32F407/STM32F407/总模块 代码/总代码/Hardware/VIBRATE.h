#ifndef __VIBRATE_H
#define __VIBRATE_H

#define VIBRATE_PIN    GPIO_Pin_11
#define VIBRATE_PORT   GPIOA
void VIBRATE_Init(void);
uint8_t VIBRATE_Get(void);

#endif
