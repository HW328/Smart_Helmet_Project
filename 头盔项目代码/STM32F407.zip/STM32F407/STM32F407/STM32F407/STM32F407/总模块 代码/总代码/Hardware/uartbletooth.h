#ifndef __USARTBLETOOTH_H
#define __USARTBLETOOTH_H
#include "stm32f4xx.h"

#define USART3_BAUDRATE 115200  

void USART3_Init(void);
void USART3_SendChar(uint8_t ch);
uint8_t USART3_ReceiveChar(void);
void USART3_SendString(const char* str);

#endif