#include "FMQ.h"
#include "stm32f4xx.h"  


void mfq_Init(void)
{	
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);

	GPIO_InitStructure.GPIO_Pin = FMQ_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	
	GPIO_ResetBits(GPIOE,FMQ_PIN);
}

void fmq_on()
{
	GPIO_ResetBits(FMQ_PORT, FMQ_PIN);
}

void fmq_off()
{
	GPIO_SetBits(FMQ_PORT, FMQ_PIN);
}


