#ifndef __RGB_H
#define __RGB_H

#define RED_LED_PIN    GPIO_Pin_2
#define GREEN_LED_PIN  GPIO_Pin_0
#define BLUE_LED_PIN   GPIO_Pin_1


#define RGB_PORT       GPIOB

void RGB_Init(void);
void RED_LED_ON(void);
void RED_LED_OFF(void);
void BLUE_LED_ON(void);
void BLUE_LED_OFF(void);
void GREEN_LED_ON(void);
void GREEN_LED_OFF(void);

#endif 
    