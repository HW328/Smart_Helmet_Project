
#include "stm32f4xx.h" 
#include "RGB.h"

void RGB_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);  
    
    GPIO_InitStructure.GPIO_Pin = RED_LED_PIN | GREEN_LED_PIN | BLUE_LED_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;          
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;         
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;      
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;       
    GPIO_Init(RGB_PORT, &GPIO_InitStructure);
    
  
    RED_LED_OFF();
    GREEN_LED_OFF();
    BLUE_LED_OFF();
}

void RED_LED_ON()
{
    GPIO_ResetBits(RGB_PORT, RED_LED_PIN);
}

void RED_LED_OFF()
{
    GPIO_SetBits(RGB_PORT, RED_LED_PIN);
}

void BLUE_LED_ON()
{
    GPIO_ResetBits(RGB_PORT, BLUE_LED_PIN);
}

void BLUE_LED_OFF()
{
    GPIO_SetBits(RGB_PORT, BLUE_LED_PIN);
}

void GREEN_LED_ON()
{
    GPIO_ResetBits(RGB_PORT, GREEN_LED_PIN);
}

void GREEN_LED_OFF()
{
    GPIO_SetBits(RGB_PORT, GREEN_LED_PIN);
}   
