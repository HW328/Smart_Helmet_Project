#ifndef __FMQ_H
#define __FMQ_H 

void mfq_Init(void);
void fmq(int INFRARED_Get);
#define FMQ_PIN     GPIO_Pin_14
#define FMQ_PORT		GPIOE
void fmq_on(void);
void fmq_off(void);
#endif

