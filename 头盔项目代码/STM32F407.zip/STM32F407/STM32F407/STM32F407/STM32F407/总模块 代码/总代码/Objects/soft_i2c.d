.\objects\soft_i2c.o: Hardware\soft_i2c.c
