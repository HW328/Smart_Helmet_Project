#ifndef __USART_H
#define __USART_H
#include "stm32f4xx.h"

#define USART2_BAUDRATE 9600  

void USART2_Init(void);
void USART2_SendChar(uint8_t ch);
uint8_t USART2_ReceiveChar(void);
void USART2_SendString(const char* str);

#endif
