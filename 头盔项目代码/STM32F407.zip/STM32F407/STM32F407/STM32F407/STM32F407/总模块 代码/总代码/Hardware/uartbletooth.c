#include "uartbletooth.h"
#include <string.h>

void USART3_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    USART_InitTypeDef USART_InitStruct = {0};

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);  

    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOD, &GPIO_InitStruct);

    GPIO_PinAFConfig(GPIOD, GPIO_PinSource8, GPIO_AF_USART3);  // TX
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource9, GPIO_AF_USART3);  // RX

    USART_InitStruct.USART_BaudRate = USART3_BAUDRATE;
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;
    USART_InitStruct.USART_StopBits = USART_StopBits_1;
    USART_InitStruct.USART_Parity = USART_Parity_No;
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStruct.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART3, &USART_InitStruct);

    
    USART_Cmd(USART3, ENABLE);
}

void USART3_SendChar(uint8_t ch) {
    while(!(USART3->SR & USART_SR_TXE));  
    USART3->DR = (ch & 0xFF);
}

uint8_t usart3ReceivedData = 0;  
uint8_t usart3ReceiveFlag = 0;   

void USART3_CheckReceive(void) {
    if (USART3->SR & USART_SR_RXNE) {  
        usart3ReceivedData = (uint8_t)(USART3->DR & 0xFF);
        usart3ReceiveFlag = 1;         
    }
}

void USART3_SendString(const char *str) {
    while(*str) {
        while(!(USART3->SR & USART_SR_TXE));  
        USART3->DR = (*str++ & 0xFF);         
    }
    while(!(USART3->SR & USART_SR_TC));       
}
