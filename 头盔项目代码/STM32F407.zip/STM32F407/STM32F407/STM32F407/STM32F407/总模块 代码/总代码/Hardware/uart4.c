#include "uart4.h"
#include <string.h>

void USART4_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    USART_InitTypeDef USART_InitStruct = {0};

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);  

    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStruct);

    GPIO_PinAFConfig(GPIOC, GPIO_PinSource10, GPIO_AF_UART4);  
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource11, GPIO_AF_UART4);  

    USART_InitStruct.USART_BaudRate = USART4_BAUDRATE;
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;
    USART_InitStruct.USART_StopBits = USART_StopBits_1;
    USART_InitStruct.USART_Parity = USART_Parity_No;
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStruct.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(UART4, &USART_InitStruct);

    USART_Cmd(UART4, ENABLE);
}

void USART4_SendChar(uint8_t ch) {
    while(!(UART4->SR & USART_SR_TXE));  
    UART4->DR = (ch & 0xFF);
}

uint8_t USART4_ReceiveChar(void) {
    while(!(UART4->SR & USART_SR_RXNE));  
    return (uint8_t)(UART4->DR & 0xFF);
}

void USART4_SendString(const char *str) {
    while(*str) {
        while(!(UART4->SR & USART_SR_TXE));  
        UART4->DR = (*str++ & 0xFF);         
    }
    while(!(UART4->SR & USART_SR_TC));       
}
