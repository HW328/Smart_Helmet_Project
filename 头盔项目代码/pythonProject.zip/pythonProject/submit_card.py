import os
import time
import asyncio
import aiohttp



async def report_data(card_list: list[str]):
    data = {
        "records": [
            {
                "device": os.getenv("DEVICE_SERIAL"),
                "cards": card_list
            },
        ]
    }
    print(data)
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(os.getenv("URL"), json=data) as resp:
                status = resp.status
                response_text = await resp.text()
                print(f"状态码: {status}")
                print(f"返回内容: {response_text}")
        except Exception as e:
            print(f"请求失败: {e}")


async def report_card(card_list1: list[str], card_list2: list[str]):
    data = {
        "records": []
    }
    if card_list1:
        data["records"].append({
            "device": os.getenv("DEVICE_SERIAL1"),
            "cards": card_list1
        })
    if card_list2:
        data["records"].append({
            "device": os.getenv("DEVICE_SERIAL2"),
            "cards": card_list2
        })

    print(data)
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(os.getenv("URL"), json=data) as resp:
                status = resp.status
                response_text = await resp.text()
                print(f"状态码: {status}")
                print(f"返回内容: {response_text}")
        except Exception as e:
            print(f"请求失败: {e}")

def drain_queue(q: asyncio.Queue):
    items = []
    while not q.empty():
        try:
            items.append(q.get_nowait())
            q.task_done()
        except asyncio.QueueEmpty:
            break
    return items if items else None


async def consumer(queue1: asyncio.Queue, queue2: asyncio.Queue):
    while True:
        await asyncio.sleep(10)
        q1_data = drain_queue(queue1)
        q2_data = drain_queue(queue2)
        if q1_data:
            q1_data = list(set(q1_data))
        if q2_data:
            q2_data = list(set(q2_data))
        await report_card(q1_data, q2_data)
        print(f"\n[{time.strftime('%X')}] Consumer: 获取 queue1 -> {q1_data}")
        print(f"[{time.strftime('%X')}] Consumer: 获取 queue2 -> {q2_data}\n")

if __name__ == "__main__":
    asyncio.run(report_data())
