from dotenv import load_dotenv
3

load_dotenv()
import asyncio
import serial
import serial.tools.list_ports
import serial_asyncio
from submit_card import report_data



class SerialReader(asyncio.Protocol):
    def __init__(self):
        self.buffer = b''
        self.transport = None
        self.receive_timeout = 0.5
        self.last_data_time = None

    def connection_made(self, transport):
        print("串口连接成功")
        self.transport = transport

    def data_received(self, data):
        now = asyncio.get_event_loop().time()
        self.last_data_time = now
        self.buffer += data


    def connection_lost(self, exc):
        print("串口连接断开")

    async def receive_loop(self):
        while True:
            await asyncio.sleep(0.1)
            now = asyncio.get_event_loop().time()

            if self.buffer:
                # 数据接收完成，开始处理
                card = self.handle_full_data(self.buffer)
                self.buffer = b''  # 清空缓冲区
                self.last_data_time = None
                await report_data([card])

    def handle_full_data(self, data):
        if len(data) == 8:
            card_number = data[4:6].hex().upper()
            return card_number



    def extract_segments(self, data):
        result = []
        index = 0

        while index < len(data):
            # 取出当前段的长度（单个字节）
            length = int.from_bytes(data[index:index + 1], byteorder='big')  # 把单个字节的长度转换为整数
            index += 1

            # 根据长度取出号码段
            segment = data[index:index + length]  # 获取这段字节
            segment_str = segment.hex().upper()  # 或者将其转换为十六进制字符串
            result.append(segment_str)

            # 更新索引指针
            index += length

        return result



    # def extract_segments(self, data):
    #     result = []
    #     index = 0
    #     while index < len(data):
    #         length = data[index]
    #         index += 1
    #         segment = data[index:index + length]
    #         segment_str = segment.hex().upper()
    #         result.append(segment_str)
    #         index += length
    #     return result


async def main(port_name):
    loop = asyncio.get_running_loop()
    protocol = SerialReader()

    try:
        transport, _ = await serial_asyncio.create_serial_connection(
            loop, lambda: protocol, port_name, baudrate=57600
        )
    except Exception as e:
        print(f"打开串口失败: {e}")
        return

    await protocol.receive_loop()


def get_available_ports():
    ports = serial.tools.list_ports.comports()
    return [str(port.device) for port in ports]


if __name__ == "__main__":
    ports = get_available_ports()
    print("可用串口：", ports)

    if ports:
        asyncio.run(main(ports[0]))  # 自动选择第一个串口，如需指定可改为 'COM5' 等
    else:
        print("未找到可用串口")
