from dotenv import load_dotenv
load_dotenv()
import asyncio
import serial
import serial.tools.list_ports
import serial_asyncio
from submit_card import report_data, consumer

queue1 = asyncio.Queue(maxsize=100)
queue2 = asyncio.Queue(maxsize=100)

class SerialReader(asyncio.Protocol):
    def __init__(self):
        self.buffer = b''
        self.transport = None
        self.receive_timeout = 0.5
        self.last_data_time = None

    def connection_made(self, transport):
        print("串口连接成功")
        self.transport = transport

    def data_received(self, data):
        now = asyncio.get_event_loop().time()
        self.last_data_time = now
        self.buffer += data


    def connection_lost(self, exc):
        print("串口连接断开")

    async def receive_loop(self):
        while True:
            await asyncio.sleep(0.1)
            now = asyncio.get_event_loop().time()

            if self.buffer:
                print(self.buffer)
                # 数据接收完成，开始处理
                if len(self.buffer) %8 == 0:
                    for i in (8, len(self.buffer), 8):
                        chunk = self.buffer[i - 8: i]
                        if chunk[1] == 1:
                            await queue1.put(chunk[4:6].hex().upper())
                        elif chunk[1] == 2:
                            await queue2.put(chunk[4:6].hex().upper())
                self.buffer = b''  # 清空缓冲区
                self.last_data_time = None



async def main(port_name):
    loop = asyncio.get_running_loop()
    protocol = SerialReader()

    try:
        transport, _ = await serial_asyncio.create_serial_connection(
            loop, lambda: protocol, port_name, baudrate=57600
        )
    except Exception as e:
        print(f"打开串口失败: {e}")
        return

    await asyncio.gather(
        protocol.receive_loop(),
        consumer(queue1, queue2)
    )
    # await consumer(queue1, queue2)
    # print("asdf")
    # await


def get_available_ports():
    ports = serial.tools.list_ports.comports()
    return [str(port.device) for port in ports]


if __name__ == "__main__":
    ports = get_available_ports()
    print("可用串口：", ports)

    if ports:
        asyncio.run(main(ports[0]))  # 自动选择第一个串口，如需指定可改为 'COM5' 等
    else:
        print("未找到可用串口")
